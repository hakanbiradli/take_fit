import 'package:flutter/material.dart';
import 'package:get/get_navigation/src/root/get_material_app.dart';
import 'package:shared_preferences/shared_preferences.dart';

import 'contans/app_text.dart';

import 'screens/login_screen.dart';


void main() async {
  WidgetsFlutterBinding.ensureInitialized();
  SharedPreferences prefs = await SharedPreferences.getInstance();
  String? selectedLanguage = prefs.getString('selectedLanguage');
  int? selectedThemeIndex = prefs.getInt('selectedThemeIndex');
  runApp(MyApp(selectedLanguage: selectedLanguage, selectedThemeIndex: selectedThemeIndex));
}

class MyApp extends StatelessWidget {
  final String? selectedLanguage;
  final int? selectedThemeIndex;

  const MyApp({Key? key, this.selectedLanguage, this.selectedThemeIndex}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return GetMaterialApp(
      debugShowCheckedModeBanner: false,
      translations: LocalString(),
      locale: _getLocale(selectedLanguage),
      theme: _getThemeData(selectedThemeIndex),
      home: LoginScreen(),
    );
  }

  Locale _getLocale(String? languageCode) {
    switch (languageCode) {
      case 'tr':
        return Locale("tr", "TR");
      case 'en':
        return Locale("en", "US");
      default:
        return Locale("tr", "TR");
    }
  }

  ThemeData _getThemeData(int? themeIndex) {
    return themeIndex == 1 ? _darkMode() : _lightMode();
  }

  ThemeData _lightMode() {
    return ThemeData(
      brightness: Brightness.light,
      primarySwatch: Colors.blue,
      fontFamily: 'Roboto',
    );
  }

  ThemeData _darkMode() {
    return ThemeData(
      brightness: Brightness.dark,
      primarySwatch: Colors.grey,
      fontFamily: 'Roboto',
    );
  }
}
